"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { MapPin, Briefcase, Inbox } from "lucide-react";
import { type Lang } from "@/lib/client/types";
import { t } from "@/lib/i18n";
import { haptic } from "@/hooks/use-telegram";

interface Application {
  id: string;
  status: "PENDING" | "FORWARDED" | "ACCEPTED" | "REJECTED";
  createdAt: string;
  message: string | null;
  job: {
    id: string;
    title: string;
    location: string | null;
    salary: string | null;
    subjects: string;
    gradeLevel: string | null;
    workType: string;
    status: string;
    deadline: string | null;
    employer: {
      companyName: string | null;
      companyTelegram: string | null;
      verification: string;
    };
  };
}

interface Props {
  lang: Lang;
  initData: string;
  onSelectJob: (jobId: string) => void;
  tg: unknown;
}

const statusColor: Record<string, string> = {
  PENDING: "bg-amber-100 text-amber-700",
  FORWARDED: "bg-blue-100 text-blue-700",
  ACCEPTED: "bg-green-100 text-green-700",
  REJECTED: "bg-red-100 text-red-700",
};

export default function ApplicationsView({ lang, initData, onSelectJob, tg }: Props) {
  const [apps, setApps] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchApps = async () => {
    setLoading(true);
    try {
      const headers: HeadersInit = {};
      if (initData) headers["x-telegram-init-data"] = initData;
      const res = await fetch("/api/applications", { headers });
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      setApps(data.applications ?? []);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApps();
  }, []);

  const statusLabel = (s: string) => {
    if (s === "PENDING") return t(lang, "appsStatusPending");
    if (s === "FORWARDED") return t(lang, "appsStatusForwarded");
    if (s === "ACCEPTED") return t(lang, "appsStatusAccepted");
    return t(lang, "appsStatusRejected");
  };

  return (
    <div className="flex flex-col gap-3 px-3 pb-24 pt-3">
      <h1 className="text-xl font-bold">{t(lang, "appsTitle")}</h1>

      {loading ? (
        <div className="flex flex-col gap-2.5">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="p-4">
              <Skeleton className="h-5 w-3/4 mb-2" />
              <Skeleton className="h-3 w-1/2" />
            </Card>
          ))}
        </div>
      ) : apps.length === 0 ? (
        <Card className="p-8 text-center text-muted-foreground flex flex-col items-center gap-3">
          <Inbox className="h-8 w-8 opacity-40" />
          <p className="text-sm">{t(lang, "appsEmpty")}</p>
        </Card>
      ) : (
        <div className="flex flex-col gap-2.5">
          {apps.map((a) => (
            <Card
              key={a.id}
              className="p-4 cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => { haptic(tg as never, "light"); onSelectJob(a.job.id); }}
            >
              <div className="flex items-start justify-between gap-2 mb-1.5">
                <h3 className="font-semibold text-[15px] leading-snug flex-1">{a.job.title}</h3>
                <Badge variant="secondary" className={`text-[10px] h-5 ${statusColor[a.status] ?? ""}`}>
                  {statusLabel(a.status)}
                </Badge>
              </div>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground mb-2">
                <span>{a.job.employer.companyName ?? "—"}</span>
                {a.job.location && (
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {a.job.location}
                  </span>
                )}
                <span className="inline-flex items-center gap-1">
                  <Briefcase className="h-3 w-3" />
                  {a.job.salary ?? t(lang, "negotiable")}
                </span>
              </div>
              {a.message && (
                <p className="text-xs text-muted-foreground line-clamp-2 italic">“{a.message}”</p>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
