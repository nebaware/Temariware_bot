// POST /api/admin/jobs/[id] — approve or reject a job, with optional broadcast
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { authenticate, MINI_APP_URL } from "@/lib/auth";
import { sendMessage } from "@/lib/telegram";
import { JobStatus, JobType, UserRole } from "@prisma/client";
import { t, type Lang } from "@/lib/i18n";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const user = await authenticate(request);
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin only" }, { status: 403 });
  }

  const body = await request.json();
  const action: "approve" | "reject" = body.action;
  const reason: string | undefined = body.reason;

  const job = await db.job.findUnique({
    where: { id },
    include: { employer: true },
  });
  if (!job) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  if (action === "approve") {
    await db.job.update({ where: { id }, data: { status: JobStatus.APPROVED, rejectionReason: null } });

    // Notify employer
    if (job.employer?.telegramId) {
      const lang = (job.employer.language ?? "en") as Lang;
      await sendMessage({
        chatId: job.employer.telegramId,
        text: t(lang, "botJobApproved", { title: job.title }),
        replyMarkup: {
          inline_keyboard: [[
            { text: t(lang, "botOpenApp"), web_app: { url: `${MINI_APP_URL}?startapp=job_${job.id}` } },
          ]],
        },
      });
    }

    // Broadcast to channel (if ALERT_CHAT_ID is set)
    let channelPosted = false;
    try {
      channelPosted = await postToChannel(job);
    } catch (e) {
      console.error("[channel broadcast] error:", e);
    }

    // Broadcast to individual subscribers
    let broadcastCount = 0;
    try {
      broadcastCount = await broadcastNewJob(job);
    } catch (e) {
      console.error("[broadcast] error:", e);
    }

    return NextResponse.json({ ok: true, broadcastCount, channelPosted });
  }

  if (action === "reject") {
    await db.job.update({
      where: { id },
      data: { status: JobStatus.REJECTED, rejectionReason: reason ?? null },
    });
    if (job.employer?.telegramId) {
      const lang = (job.employer.language ?? "en") as Lang;
      await sendMessage({
        chatId: job.employer.telegramId,
        text: t(lang, "botJobRejected", { title: job.title, reason: reason ?? "—" }),
      });
    }
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}

async function postToChannel(job: {
  id: string;
  title: string;
  description: string;
  subjects: string;
  location: string | null;
  salary: string | null;
  workType: JobType;
  gradeLevel: string | null;
  genderPref: string | null;
  languageReq: string | null;
  deadline: Date | null;
  hoursPerWeek: string | null;
  contactTelegram: string | null;
}): Promise<boolean> {
  const channelId = process.env.ALERT_CHAT_ID;
  if (!channelId) return false;

  // Build a richer card for the channel (English — channel is public-facing)
  const deadlineStr = job.deadline
    ? new Date(job.deadline).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })
    : "Open";
  const genderStr = !job.genderPref || job.genderPref === "any"
    ? "Any"
    : job.genderPref.charAt(0).toUpperCase() + job.genderPref.slice(1);
  const workTypeLabel = {
    TUTORING: "Tutoring", FREELANCE: "Freelance", PART_TIME: "Part-time",
    FULL_TIME: "Full-time", INTERNSHIP: "Internship", REMOTE: "Remote",
  }[job.workType] ?? job.workType;

  const text =
    `📢 *New Job on Temariware*\n\n` +
    `*${job.title}*\n\n` +
    `📚 Subjects: ${job.subjects}\n` +
    `🎓 Level: ${job.gradeLevel ?? "—"}\n` +
    `📍 Location: ${job.location ?? "—"}\n` +
    `💼 Type: ${workTypeLabel}\n` +
    `💰 Salary: ${job.salary ?? "Negotiable"}\n` +
    `⏰ Schedule: ${job.hoursPerWeek ?? "—"}\n` +
    `👤 Gender pref: ${genderStr}\n` +
    (job.languageReq ? `🗣 Language: ${job.languageReq}\n` : "") +
    `📅 Deadline: ${deadlineStr}\n\n` +
    `${job.description.length > 300 ? job.description.slice(0, 300) + "…" : job.description}\n\n` +
    `👉 Tap below to view full details & apply:`;

  const res = await sendMessage({
    chatId: channelId,
    text,
    replyMarkup: {
      inline_keyboard: [[
        { text: "View & apply", web_app: { url: `${MINI_APP_URL}?startapp=job_${job.id}` } },
        { text: "Open Temariware", web_app: { url: MINI_APP_URL } },
      ]],
    },
    disablePreview: false,
  });
  return !!res;
}

async function broadcastNewJob(job: {
  id: string;
  title: string;
  description: string;
  subjects: string;
  location: string | null;
  salary: string | null;
  workType: JobType;
  gradeLevel: string | null;
  genderPref: string | null;
  languageReq: string | null;
}): Promise<number> {
  // Find subscribers whose category matches the job type, or "ALL"
  const jobCategory = job.workType as string; // e.g. "TUTORING"
  const subs = await db.subscription.findMany({
    where: { OR: [{ category: jobCategory }, { category: "ALL" }] },
    include: { user: { select: { telegramId: true, language: true, id: true } } },
  });

  // Deduplicate users (a user may have both ALL + TUTORING subs)
  const seen = new Set<string>();
  let count = 0;
  for (const sub of subs) {
    if (seen.has(sub.user.id)) continue;
    seen.add(sub.user.id);

    // Match against alert subjects if user set them
    if (sub.user.id !== job.employer?.id && sub.user.telegramId) {
      const lang = (sub.user.language ?? "en") as Lang;
      const text = t(lang, "botNewJobAlert", {
        title: job.title,
        location: job.location ?? "—",
        subjects: job.subjects,
        salary: job.salary ?? "—",
      });
      await sendMessage({
        chatId: sub.user.telegramId,
        text,
        replyMarkup: {
          inline_keyboard: [[
            { text: t(lang, "viewDetails"), web_app: { url: `${MINI_APP_URL}?startapp=job_${job.id}` } },
          ]],
        },
      });
      count++;
    }
  }
  return count;
}
