// GET /api/jobs — list approved jobs (with filters)
// POST /api/jobs — submit a new job (verified employers only)
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { authenticate } from "@/lib/auth";
import { JobStatus, JobType, VerificationStatus } from "@prisma/client";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const subject = url.searchParams.get("subject");
  const location = url.searchParams.get("location");
  const workType = url.searchParams.get("workType");
  const grade = url.searchParams.get("grade");
  const gender = url.searchParams.get("gender");
  const languageReq = url.searchParams.get("languageReq");
  const search = url.searchParams.get("q");
  const limit = Math.min(50, Number(url.searchParams.get("limit") ?? 30));
  const offset = Math.max(0, Number(url.searchParams.get("offset") ?? 0));

  const where: Record<string, unknown> = { status: JobStatus.APPROVED };

  if (subject) {
    where.OR = [
      { subjects: { contains: subject } },
      { subjects: { contains: subject.charAt(0).toUpperCase() + subject.slice(1) } },
    ];
  }
  if (location) {
    where.location = { contains: location };
  }
  if (workType) {
    where.workType = workType as JobType;
  }
  if (grade) {
    where.gradeLevel = { contains: grade };
  }
  if (gender && gender !== "any") {
    where.OR = [
      { genderPref: gender },
      { genderPref: null },
      { genderPref: "any" },
    ];
  }
  if (languageReq) {
    where.OR = [
      { languageReq: { contains: languageReq } },
      { languageReq: null },
    ];
  }
  if (search) {
    where.OR = [
      { title: { contains: search } },
      { description: { contains: search } },
      { subjects: { contains: search } },
      { location: { contains: search } },
    ];
  }

  const jobs = await db.job.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: limit,
    skip: offset,
    include: {
      employer: {
        select: {
          id: true,
          companyName: true,
          companyTelegram: true,
          username: true,
          firstName: true,
          verification: true,
        },
      },
      _count: { select: { applications: true } },
    },
  });

  return NextResponse.json({ jobs });
}

export async function POST(request: Request) {
  const user = await authenticate(request);
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (user.verification !== VerificationStatus.APPROVED && !user.isAdmin) {
    return NextResponse.json(
      { error: "Only verified employers can post jobs. Please verify your company first." },
      { status: 403 }
    );
  }

  const body = await request.json();
  const required = ["title", "description", "subjects"];
  for (const f of required) {
    if (!body[f] || typeof body[f] !== "string" || body[f].trim().length === 0) {
      return NextResponse.json({ error: `Missing field: ${f}` }, { status: 400 });
    }
  }

  const job = await db.job.create({
    data: {
      title: body.title.trim(),
      description: body.description.trim(),
      employerId: user.id,
      subjects: body.subjects.trim(),
      gradeLevel: body.gradeLevel?.trim() || null,
      location: body.location?.trim() || null,
      workType: (body.workType as JobType) ?? JobType.TUTORING,
      salary: body.salary?.trim() || null,
      currency: "ETB",
      hoursPerWeek: body.hoursPerWeek?.trim() || null,
      genderPref: body.genderPref || null,
      languageReq: body.languageReq?.trim() || null,
      deadline: body.deadline ? new Date(body.deadline) : null,
      contactTelegram: body.contactTelegram?.trim() || user.companyTelegram || null,
      status: JobStatus.PENDING,
    },
  });

  return NextResponse.json({ job });
}
